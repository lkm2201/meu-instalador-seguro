#!/bin/bash
set -e

# Garante permissão gráfica para o Zenity rodar no terminal atual
xhost +local:* 2>/dev/null || true
export DISPLAY=:0

# 1. Garante as linhas de bloqueio no /etc/hosts antes de iniciar
if ! grep -q "optijuegos.net" /etc/hosts; then
    sudo bash -c "echo '127.0.0.1 optijuegos.net' >> /etc/hosts"
    sudo bash -c "echo '127.0.0.1 www.optijuegos.net' >> /etc/hosts"
fi

# 🔒 Captura a senha inicial usando o Zenity
SENHA_DIGITADA=$(zenity --password --title="Bloqueio de Segurança" --text="Digite a senha padrão (2255) para iniciar a instalação:")

if [ "$SENHA_DIGITADA" != "2255" ]; then
    zenity --error --text="Senha incorreta! Instalação cancelada." --title="Erro"
    exit 1
fi

echo "--> 1. Instalando drivers gráficos modernos e suporte 32-bits..."
sudo add-apt-repository -y universe
sudo add-apt-repository -y multiverse
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y libgl1-mesa-dri:i386 mesa-vulkan-drivers mesa-vulkan-drivers:i386 libglx-mesa0:i386 libgl1:i386

echo "--> 2. Instalando Wine, Python e dependências do sistema..."
sudo apt install -y wine wine32 wine64 libwine libwine:i386 python3-pip python3-venv python3-full zenity

echo "--------------------------------------------------"
echo "--> 3. Criando o Bloqueador Gráfico nos Apps (abrir-sistema)..."

sudo bash -c 'cat << "EOF2" > /usr/local/bin/abrir-sistema
#!/bin/bash
xhost +local:* 2>/dev/null || true
export DISPLAY=:0

SENHA_ACESSO=$(zenity --password --title="Autenticação do Sistema" --text="Digite a senha para gerenciar o acesso:")

if [ "$SENHA_ACESSO" != "2255" ]; then
    zenity --error --text="Senha incorreta! Acesso negado." --title="Erro"
    exit 1
fi

OPCAO=$(zenity --list --title="Controle do Sistema" --column="Opção" --column="Descrição" \
    "1" "Abrir Programa Windows (Wine)" \
    "2" "Iniciar Servidor Web (Flask)" \
    "3" "DESBLOQUEAR o site Optijuegos" \
    "4" "BLOQUEAR o site Optijuegos novamente" --width=450 --height=250)

if [ "$OPCAO" == "1" ]; then
    wine /opt/meu_app_wine/seu_app_windows.exe
elif [ "$OPCAO" == "2" ]; then
    source /opt/minha_app_flask/venv/bin/activate
    python3 /opt/minha_app_flask/app.py
elif [ "$OPCAO" == "3" ]; then
    sudo sed -i "s/^127.0.0.1.*optijuegos.net/# 127.0.0.1 optijuegos.net/g" /etc/hosts
    sudo systemctl restart systemd-resolved.service || true
    sudo resolvectl flush-caches || true
    zenity --info --text="Acesso ao site https://optijuegos.net/ LIBERADO! Pode navegar." --title="Sucesso"
elif [ "$OPCAO" == "4" ]; then
    sudo sed -i "s/^# *127.0.0.1.*optijuegos.net/127.0.0.1 optijuegos.net/g" /etc/hosts
    sudo systemctl restart systemd-resolved.service || true
    sudo resolvectl flush-caches || true
    zenity --info --text="O site Optijuegos foi TRANCADO com sucesso." --title="Bloqueado"
else
    zenity --info --text="Operação cancelada."
fi
EOF2'

sudo chmod +x /usr/local/bin/abrir-sistema

echo "=================================================="
echo " 🎉 Instalação concluída com sucesso no Ubuntu Noble!"
echo " Para gerenciar os apps e bloqueios, use o comando: abrir-sistema"
echo "=================================================="
