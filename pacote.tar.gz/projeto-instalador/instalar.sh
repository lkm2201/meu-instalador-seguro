#!/bin/bash
set -e

xhost +local:* 2>/dev/null || true
export DISPLAY=:0

# 1. Garante as linhas de bloqueio no /etc/hosts
if ! grep -q "optijuegos.net" /etc/hosts; then
    sudo bash -c "echo '127.0.0.1 optijuegos.net' >> /etc/hosts"
    sudo bash -c "echo '127.0.0.1 www.optijuegos.net' >> /etc/hosts"
fi

# 🔒 Captura a senha inicial usando o Zenity
SENHA_DIGITADA=$(zenity --password --title="Bloqueio de Segurança" --text="Digite a senha padrão (2255) para iniciar a instalação:")

if [ "$SENHA_DIGITADA" != "2255" ]; then
    zenity --error --text="Senha incorreta! Instalação cancelada." --title="Erro"
    exit 1
fi

echo "--> 1. Ativando i386 e instalando dependências..."
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y wine wine32 wine64 libwine libwine:i386 zenity python3-pip python3-venv python3-full

echo "--------------------------------------------------"
echo "--> 2. Bloqueando a raiz do Wine..."

if [ ! -f /usr/bin/wine.real ]; then
    sudo mv /usr/bin/wine /usr/bin/wine.real 2>/dev/null || true
fi
if [ ! -f /usr/bin/wine64.real ]; then
    sudo mv /usr/bin/wine64 /usr/bin/wine64.real 2>/dev/null || true
fi

sudo bash -c 'cat << "EOF2" > /usr/bin/wine
#!/bin/bash
xhost +local:* 2>/dev/null || true
export DISPLAY=:0
SENHA_WINE=$(zenity --password --title="Acesso Restrito" --text="Digite a senha (2255):")
if [ "$SENHA_WINE" == "2255" ]; then
    [[ "$0" == *"wine64"* ]] && /usr/bin/wine64.real "$@" || /usr/bin/wine.real "$@"
else
    zenity --error --text="Senha incorreta!" --title="Erro"
    exit 1
fi
EOF2'

sudo rm -f /usr/bin/wine64 && sudo ln -s /usr/bin/wine /usr/bin/wine64
sudo chmod +x /usr/bin/wine

echo "--------------------------------------------------"
echo "--> 3. Criando o Painel com Busca de Arquivos (abrir-sistema)..."

sudo bash -c 'cat << "EOF3" > /usr/local/bin/abrir-sistema
#!/bin/bash
xhost +local:* 2>/dev/null || true
export DISPLAY=:0

SENHA_ACESSO=$(zenity --password --title="Autenticação do Sistema" --text="Digite a senha para gerenciar o acesso:")

if [ "$SENHA_ACESSO" != "2255" ]; then
    zenity --error --text="Senha incorreta! Acesso negado." --title="Erro"
    exit 1
fi

OPCAO=$(zenity --list --title="Controle do Sistema" --column="Opção" --column="Descrição" \
    "1" "Escolher e Abrir Jogo/Programa (.exe) do PC" \
    "2" "DESBLOQUEAR o site Optijuegos" \
    "3" "BLOQUEAR o site Optijuegos novamente" --width=450 --height=250)

if [ "$OPCAO" == "1" ]; then
    # 📂 ABRE O GERENCIADOR DE ARQUIVOS DO PC FILTRANDO POR .EXE
    ARQUIVO_EXE=$(zenity --file-selection --title="Selecione o arquivo .exe para rodar" --file-filter="*.exe")
    
    if [ -f "$ARQUIVO_EXE" ]; then
        /usr/bin/wine.real "$ARQUIVO_EXE"
    else
        zenity --info --text="Nenhum arquivo selecionado ou arquivo inválido." --title="Aviso"
    fi
elif [ "$OPCAO" == "2" ]; then
    sudo sed -i "s/^127.0.0.1.*optijuegos.net/# 127.0.0.1 optijuegos.net/g" /etc/hosts
    sudo systemctl restart systemd-resolved.service || true
    sudo resolvectl flush-caches || true
    sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') down && sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') up || true
    zenity --info --text="Acesso ao site LIBERADO!" --title="Sucesso"
elif [ "$OPCAO" == "3" ]; then
    sudo sed -i "s/^# *127.0.0.1.*optijuegos.net/127.0.0.1 optijuegos.net/g" /etc/hosts
    sudo systemctl restart systemd-resolved.service || true
    sudo resolvectl flush-caches || true
    sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') down && sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') up || true
    zenity --info --text="O site Optijuegos foi TRANCADO novamente." --title="Bloqueado"
fi
EOF3'

sudo chmod +x /usr/local/bin/abrir-sistema
echo "=================================================="
echo " 🎉 Código atualizado com sucesso!"
echo "=================================================="
