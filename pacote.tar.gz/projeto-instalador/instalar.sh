#!/bin/bash
set -e

xhost +local:* 2>/dev/null || true
export DISPLAY=:0

# 1. Bloqueio preventivo do site
if ! grep -q "optijuegos.net" /etc/hosts; then
    sudo bash -c "echo '127.0.0.1 optijuegos.net' >> /etc/hosts"
    sudo bash -c "echo '127.0.0.1 www.optijuegos.net' >> /etc/hosts"
fi

# 🔒 Autenticação do instalador
SENHA_DIGITADA=$(zenity --password --title="Bloqueio de Segurança" --text="Digite a senha padrão (2255) para iniciar a instalação:")
if [ "$SENHA_DIGITADA" != "2255" ]; then
    zenity --error --text="Senha incorreta! Instalação cancelada." --title="Erro"
    exit 1
fi

echo "--> 1. Preparando o Ubuntu para receber o WINE-DEVEL (32 e 64 bits)..."
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y wget gnupg2 software-properties-common zenity cabextract python3-pip python3-venv python3-full

# 🔑 ADICIONANDO A CHAVE CORRETA DA WINEHQ (Link Atualizado sem Erro 404)
sudo mkdir -pm755 /etc/apt/keyrings
sudo wget -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/winehq/winehq.key

# 🌐 ADICIONANDO O REPOSITÓRIO OFICIAL DA WINEHQ
UBUNTU_CODENAME=$(lsb_release -cs)
sudo wget -NP /etc/apt/sources.list.d/ https://dl.winehq.org/winehq/wine/ubuntu/dists/${UBUNTU_CODENAME}/winehq-${UBUNTU_CODENAME}.sources

sudo apt update

echo "--> 2. Baixando e Instalando estritamente o WINE-DEVEL..."
# Comando explícito exigindo a versão de Desenvolvimento da WineHQ
sudo apt install -y --install-recommends winehq-devel winetricks

echo "--------------------------------------------------"
echo "--> 3. Injetando Componentes do Windows no prefixo do Wine-Devel..."
# Aponta o winetricks para rodar o motor do wine-devel
export WINE=/opt/wine-devel/bin/wine
winetricks -q d3dx9 corefonts vcrun2015 || true

echo "--------------------------------------------------"
echo "--> 4. Criando Bloqueio com Senha para os comandos do Wine-Devel..."
sudo mkdir -p /usr/bin

# Substitui o comando 'wine' padrão pelo nosso interceptor com senha que chama o devel real
sudo bash -c 'cat << "EOF2" > /usr/bin/wine
#!/bin/bash
xhost +local:* 2>/dev/null || true
export DISPLAY=:0
SENHA_WINE=$(zenity --password --title="Acesso Restrito" --text="Digite a senha (2255):")
if [ "$SENHA_WINE" == "2255" ]; then
    /opt/wine-devel/bin/wine "$@"
else
    zenity --error --text="Senha incorreta!" --title="Erro"
    exit 1
fi
EOF2'

# Substitui o comando 'wine64' padrão pelo nosso interceptor com senha que chama o devel de 64 bits real
sudo bash -c 'cat << "EOF3" > /usr/bin/wine64
#!/bin/bash
xhost +local:* 2>/dev/null || true
export DISPLAY=:0
SENHA_WINE=$(zenity --password --title="Acesso Restrito" --text="Digite a senha (2255):")
if [ "$SENHA_WINE" == "2255" ]; then
    /opt/wine-devel/bin/wine64 "$@"
else
    zenity --error --text="Senha incorreta!" --title="Erro"
    exit 1
fi
EOF3'

sudo chmod +x /usr/bin/wine /usr/bin/wine64

echo "--------------------------------------------------"
echo "--> 5. Gerando Painel Administrativo de Controle (abrir-sistema)..."
sudo bash -c 'cat << "EOF4" > /usr/local/bin/abrir-sistema
#!/bin/bash
xhost +local:* 2>/dev/null || true
export DISPLAY=:0

SENHA_ACESSO=$(zenity --password --title="Autenticação do Sistema" --text="Digite a senha para gerenciar o acesso:")
if [ "$SENHA_ACESSO" != "2255" ]; then
    zenity --error --text="Senha incorreta! Acesso negado." --title="Erro"
    exit 1
fi

OPCAO=$(zenity --list --title="Controle do Sistema" --column="Opção" --column="Descrição" \
    "1" "Escolher e Abrir Jogo/Programa (.exe) do PC usando Wine-Devel" \
    "2" "Abrir Painel do WINETRICKS manualmente" \
    "3" "DESBLOQUEAR o site Optijuegos" \
    "4" "BLOQUEAR o site Optijuegos novamente" --width=500 --height=280)

if [ "$OPCAO" == "1" ]; then
    ARQUIVO_EXE=$(zenity --file-selection --title="Selecione o arquivo .exe para rodar" --file-filter="*.exe")
    if [ -f "$ARQUIVO_EXE" ]; then
        /opt/wine-devel/bin/wine "$ARQUIVO_EXE"
    fi
elif [ "$OPCAO" == "2" ]; then
    WINE=/opt/wine-devel/bin/wine winetricks --gui &
elif [ "$OPCAO" == "3" ]; then
    sudo sed -i "s/^127.0.0.1.*optijuegos.net/# 127.0.0.1 optijuegos.net/g" /etc/hosts
    sudo systemctl restart systemd-resolved.service || true
    sudo resolvectl flush-caches || true
    sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') down && sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') up || true
    zenity --info --text="Acesso ao site LIBERADO!" --title="Sucesso"
elif [ "$OPCAO" == "4" ]; then
    sudo sed -i "s/^# *127.0.0.1.*optijuegos.net/127.0.0.1 optijuegos.net/g" /etc/hosts
    sudo systemctl restart systemd-resolved.service || true
    sudo resolvectl flush-caches || true
    sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') down && sudo ip link set dev $(ip route show default | awk '"'"'{print $5}'"'"') up || true
    zenity --info --text="O site Optijuegos foi TRANCADO novamente." --title="Bloqueado"
fi
EOF4'

sudo chmod +x /usr/local/bin/abrir-sistema
echo "=================================================="
echo " 🎉 Instalação do Wine-Devel configurada com sucesso!"
echo "=================================================="
